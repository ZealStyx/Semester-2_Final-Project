package io.github.superteam.resonance.interactable.door;

import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import io.github.superteam.resonance.event.EventContext;
import io.github.superteam.resonance.interactable.Interactable;

/**
 * Basic door interactable with lock states and animated angle target.
 */
public final class DoorController implements Interactable {
    private static final float OPEN_ANGLE_DEGREES = 90f;
    private static final float MOVE_INTERPOLATION = 5f;

    private final String id;
    private final Vector3 hingePosition;
    private final float interactionRadius;
    private final DoorCreakSystem creakSystem = new DoorCreakSystem();

    private DoorLockState lockState = DoorLockState.UNLOCKED;
    private float currentAngle;
    private float targetAngle;
    private float creakCooldownSeconds;
    private float pendingNoiseIntensity;

    public DoorController(String id, Vector3 hingePosition, float interactionRadius) {
        this.id = id == null ? "door" : id;
        this.hingePosition = hingePosition == null ? new Vector3() : new Vector3(hingePosition);
        this.interactionRadius = Math.max(0.2f, interactionRadius);
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public Vector3 worldPosition() {
        return new Vector3(hingePosition);
    }

    @Override
    public float interactionRadius() {
        return interactionRadius;
    }

    public void setLockState(DoorLockState lockState) {
        this.lockState = lockState == null ? DoorLockState.UNLOCKED : lockState;
    }

    public DoorLockState lockState() {
        return lockState;
    }

    public float currentAngle() {
        return currentAngle;
    }

    public float consumeNoiseIntensity() {
        float value = pendingNoiseIntensity;
        pendingNoiseIntensity = 0f;
        return value;
    }

    @Override
    public void onInteract(EventContext ctx) {
        if (lockState != DoorLockState.UNLOCKED) {
            if (ctx != null && ctx.audioSystem() != null) {
                ctx.audioSystem().playSound("audio/sfx/door/locked.wav", 0.65f);
            }
            pendingNoiseIntensity = Math.max(pendingNoiseIntensity, 0.22f);
            return;
        }

        targetAngle = currentAngle < (OPEN_ANGLE_DEGREES * 0.5f) ? OPEN_ANGLE_DEGREES : 0f;
    }

    public void update(float deltaSeconds, EventContext eventContext) {
        creakCooldownSeconds = Math.max(0f, creakCooldownSeconds - Math.max(0f, deltaSeconds));

        float previousAngle = currentAngle;
        currentAngle = MathUtils.lerpAngleDeg(currentAngle, targetAngle, Math.min(1f, Math.max(0f, deltaSeconds) * MOVE_INTERPOLATION));
        float angularSpeed = deltaSeconds > 0.0001f
            ? Math.abs(currentAngle - previousAngle) / deltaSeconds
            : 0f;

        DoorCreakSystem.CreakSample sample = creakSystem.sample(angularSpeed);
        if (sample.volume() > 0.05f && creakCooldownSeconds <= 0f && eventContext != null && eventContext.audioSystem() != null) {
            if (eventContext.playerPosition() != null) {
                eventContext.audioSystem().playSfx(
                    "audio/sfx/door/creak_soft.wav",
                    hingePosition,
                    eventContext.playerPosition(),
                    sample.volume()
                );
            } else {
                eventContext.audioSystem().playSound("audio/sfx/door/creak_soft.wav", sample.volume());
            }
            pendingNoiseIntensity = Math.max(pendingNoiseIntensity, sample.volume());
            creakCooldownSeconds = MathUtils.lerp(0.35f, 0.1f, MathUtils.clamp(sample.volume(), 0f, 1f));
        }
    }
}
