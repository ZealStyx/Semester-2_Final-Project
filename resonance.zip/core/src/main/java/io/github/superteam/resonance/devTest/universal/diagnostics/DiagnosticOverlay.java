package io.github.superteam.resonance.devTest.universal.diagnostics;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import io.github.superteam.resonance.devTest.universal.TestZone;

public final class DiagnosticOverlay {
    private final TabCycler tabCycler = new TabCycler();
    private final PerformanceCounter performanceCounter = new PerformanceCounter();
    private final SystemStatePanel systemStatePanel = new SystemStatePanel();

    public void update() {
        tabCycler.update();
    }

    public void draw(SpriteBatch batch, BitmapFont font, TestZone activeZone, int width, int height) {
        String tab = tabCycler.activeTab();
        float x = 16.0f;
        float y = height - 16.0f;
        float line = 16.0f;

        batch.begin();
        font.draw(batch, "[UniversalTestScene] TAB=" + tab, x, y);

        if ("PERFORMANCE".equals(tab)) {
            font.draw(batch, performanceCounter.summary(), x, y - line);
        } else if ("SYSTEM_STATE".equals(tab)) {
            Array<String> lines = systemStatePanel.lines(activeZone == null ? null : activeZone.getSystemState());
            for (int i = 0; i < lines.size; i++) {
                font.draw(batch, lines.get(i), x, y - ((i + 1) * line));
            }
        } else if ("ZONE".equals(tab)) {
            font.draw(batch, "ActiveZone=" + (activeZone == null ? "none" : activeZone.getZoneName()), x, y - line);
        } else {
            font.draw(batch, "WASD move | Shift run | Ctrl slow | C crouch | Space jump", x, y - line);
            font.draw(batch, "F10 from PlayerTestScreen enters this shell", x, y - (line * 2.0f));
            font.draw(batch, "F9 back to PlayerTestScreen", x, y - (line * 3.0f));
        }

        batch.end();
    }
}
